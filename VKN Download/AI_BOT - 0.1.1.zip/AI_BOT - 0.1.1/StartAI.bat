py SkryptPamiec\Wirting_AI-script.py
pause