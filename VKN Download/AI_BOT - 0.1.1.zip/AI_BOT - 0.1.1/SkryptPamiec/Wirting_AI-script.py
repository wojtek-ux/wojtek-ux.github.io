import os
import time
import random

PLIK = "pamiec82.txt"

# jeśli plik nie istnieje -> utwórz
if not os.path.exists(PLIK):
    open(PLIK, "w", encoding="utf-8").close()

print("===========================================")
print("AI działa! (exit = wyjście)")
print("-------------------------------------------")
print("Napisz (pomoc) żeby dostać dodatkowe info")
print("-------------------------------------------")
print("Created By : Wojtek | Version : 0.0.3")
print("===========================================")

while True:
    msg = input("Ty: ").lower()

    if msg == "exit":
        break

    znaleziono = False

    # czytanie pamięci
    with open(PLIK, "r", encoding="utf-8") as f:
        for linia in f:
            if "|" in linia:
                pyt, odp = linia.strip().split("|", 1)

                if pyt == msg:
                    # efekt myślenia
                    print("AI: Myślę", end="", flush=True)
                    
                    for i in range(3):
                        time.sleep(0.5)
                        print(".", end="", flush=True)

                    time.sleep(random.uniform(0.5,1.5))

                    # nadpisanie linii (usuwa Myślę...)
                    print("\rBot: " + odp + "        ")
                    znaleziono = True
                    break

    # jeśli nie zna odpowiedzi
    if not znaleziono:
        nowa = input("AI nie wie. Co ma mówić?: ")

        # zapis do pamięci
        with open(PLIK, "a", encoding="utf-8") as f:
            f.write(msg + "|" + nowa + "\n")

        print("AI: Zapamiętałem 😄")